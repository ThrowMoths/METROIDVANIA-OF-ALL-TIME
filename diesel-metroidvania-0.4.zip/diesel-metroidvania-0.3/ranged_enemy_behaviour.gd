extends Node2D

var Player:Object

@onready var rangedAttack = preload("res://Bullet.tscn")

var Health = 5

var Cooldown1 = 0.0
var MeleeCooldown = 1.1
var CanAttack = true
var Direction = 1
var KnockbackVelocity:=Vector2(0,0)

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Cooldown1 <= MeleeCooldown:
		Cooldown1 += delta
	else:
		CanAttack = true
		Cooldown1 = 0.0

func Attack():
	if CanAttack:
		CanAttack = false
		var newBullet = rangedAttack.instantiate()
		get_tree().current_scene.add_child(newBullet)
		newBullet.Owner = "enemy"
		newBullet.position = global_position
		newBullet.direction = Direction
