extends Area2D

var direction := 1
var timePassed := 0.0
var Owner = "none"
var Damage = 3
var KnockbackPower = 2000
var speed:=2000.0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().create_timer(3.0).timeout
	call_deferred("queue_free")

func _process(delta: float) -> void:
	position+=Vector2(speed,0)*direction*delta

func _on_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if Owner == "player":
		if body.is_in_group("Enemy"):
			get_tree().current_scene.hit_stop(0.1,0.1)
			body.TakeDamage(Damage)
			body.TakeKnockback(Vector2(KnockbackPower*direction,0))
	
	elif Owner == "enemy":
		if body.is_in_group("Player"):
			body.TakeDamage(Damage)
