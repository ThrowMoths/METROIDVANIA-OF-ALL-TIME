extends Node2D

@onready var Player := $Player

var CameraTarget = null
var LockedOn = false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if CameraTarget == null:
		$Camera2D.position = $Camera2D.position +3*(($Player.position-$Camera2D.position)+(get_global_mouse_position()-$Camera2D.position)*0.2) *delta*max(1,$Camera2D.position.distance_to(Player.position)/1000)
	else:
		$Camera2D.position = $Camera2D.position +3*((CameraTarget.position-$Camera2D.position)+(get_global_mouse_position()-$Camera2D.position)*0.2)*delta*max(1,$Camera2D.position.distance_to(CameraTarget.position)/1000)

func _input(event: InputEvent) -> void:
	pass
	#if event.is_action_pressed("lock_on"):
	#	LockedOn = not LockedOn
	#	if LockedOn == false:
		#	CameraTarget = null

func hit_stop(duration,strength):
	Engine.time_scale=strength
	await get_tree().create_timer(duration,true,false,true).timeout
	Engine.time_scale=1
