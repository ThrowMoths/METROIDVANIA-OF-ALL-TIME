class_name Player extends CharacterBody2D


var moveSpeed :float= 800.0
var jumpStrength :float= -1400.0
var moveVelocity:Vector2=Vector2(0,0)
var knockbackVelocity:Vector2=Vector2(0,0)

func _physics_process(delta: float) -> void:
	if not is_on_floor() and Input.is_action_pressed("Jump") and velocity.y<=0:
		moveVelocity += get_gravity() * delta*3
	elif not is_on_floor():
		moveVelocity += get_gravity() * delta*7

	if Input.is_action_just_pressed("Jump") and is_on_floor():
		moveVelocity.y = jumpStrength
	moveVelocity.y=min(moveVelocity.y,2400)
	if is_on_ceiling():
		moveVelocity.y=max(0,moveVelocity.y)
		knockbackVelocity.y=max(0,knockbackVelocity.y)
	
	var direction := Input.get_axis("Left", "Right")
	if direction:
		moveVelocity.x = direction * moveSpeed
	else:
		moveVelocity.x*=0
	velocity=moveVelocity+knockbackVelocity
	move_and_slide()
