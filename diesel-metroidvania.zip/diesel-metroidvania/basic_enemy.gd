extends CharacterBody2D

var SPEED = 500.0
var Direction = 1
var TargetPos = Vector2.ZERO
var TopRayRange = 100
var BottomRayRange = 100
var CanJump = true
var softCollVelocity:=Vector2(0,0)
var KnockbackVelocity:=Vector2(0,0)
var KnockbackMulti:= 1.0


var Player:Object

@onready var softCollider=$SoftCollision
@onready var meleeAttack = preload("res://MeleeAttack.tscn")

var Health = 5

var Cooldown1 = 0.0
var MeleeCooldown = 1.1
var CanAttack = true

var UpTilt = false


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	if not is_on_floor():
		velocity += get_gravity() * delta * 5
		
	elif UpTilt:
		velocity = Vector2.ZERO
		
	else:
		CanJump = true
	
	Player=get_tree().current_scene.Player
	Direction = sign(Player.position.x - position.x)
	
	if abs(Player.position.x - position.x) < 250 and KnockbackVelocity.x == 0:
		SPEED = 0
		Attack()
	
	$TopRay.target_position.x = Direction * TopRayRange
	$BottomRay.target_position.x = Direction * BottomRayRange
	
	if $BottomRay.get_collider():
		if $BottomRay.get_collider().is_in_group("SolidWall"):
			if CanJump and not $TopRay.get_collider():
				Jump()
	
	KnockbackVelocity = KnockbackVelocity.move_toward(Vector2(0,0),3500*delta)
	
	if softCollider.is_colliding():
		softCollVelocity+=softCollider.get_push_vector()*delta*500
	else:
		softCollVelocity*=0
	
	velocity.x = Direction * SPEED + softCollVelocity.x + KnockbackVelocity.x
	SPEED = 500.0
	move_and_slide()
	
	if Cooldown1 <= MeleeCooldown:
		Cooldown1 += delta
	else:
		CanAttack = true
		Cooldown1 = 0.0
	
func Jump():
	CanJump = false
	velocity.y = -1000

func Attack():
	if CanAttack:
		CanAttack = false
		var newMelee = meleeAttack.instantiate()
		get_tree().current_scene.add_child(newMelee)
		newMelee.Owner = "enemy"
		newMelee.position = position
		newMelee.rotation=self.get_angle_to(Player.position)

func TakeDamage(Damage):
	Health -= Damage
	if Health <= 0:
		if get_tree().current_scene.LockedOn == true:
			get_tree().current_scene.LockedOn = false
			get_tree().current_scene.CameraTarget = null
		call_deferred("queue_free")

func TakeKnockback(Vector):
	KnockbackVelocity = Vector*KnockbackMulti

func KnockUp():
	CanJump = false
	velocity.y = -2500
	UpTilt = true

func _on_mouse_entered() -> void:
	if get_tree().current_scene.LockedOn == true:
		get_tree().current_scene.CameraTarget = self
