extends Area2D

var direction := 1
var timePassed := 0.0
var Owner = "none"
var Damage = 1
var KnockbackPower = 1750

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().create_timer(0.2).timeout
	call_deferred("queue_free")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_body_entered(body: Node2D) -> void:
	if Owner == "player":
		if body.is_in_group("Enemy"):
			get_tree().current_scene.hit_stop(0.1,0.1)
			body.TakeDamage(Damage)
			body.TakeKnockback(Vector2(KnockbackPower*direction,0))
