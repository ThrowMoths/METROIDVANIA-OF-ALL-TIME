extends Area2D

var direction := 1
var timePassed := 0.0
var Owner = "none"
var Damage = 1
var KnockbackPower = 1000
var CanUpTilt = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	await get_tree().create_timer(0.2).timeout
	call_deferred("queue_free")

func _on_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if Owner == "player":
		if body.is_in_group("Enemy"):
			get_tree().current_scene.hit_stop(0.1,0.1)
			body.TakeDamage(Damage)
			if CanUpTilt == true:
				body.KnockUp()
			else:
				body.TakeKnockback(Vector2(KnockbackPower*direction,0))
		
	
	elif Owner == "enemy":
		if body.is_in_group("Player"):
			body.TakeDamage(Damage)
		
