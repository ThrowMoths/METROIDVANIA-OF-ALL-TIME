extends CharacterBody2D

@onready var meleeAttack:= preload("res://MeleeAttack.tscn")
@onready var HeavyAttack:= preload("res://heavy_attack.tscn")

const SPEED = 700.0
const JUMP_VELOCITY = -1000.0

var Health = 100
var IFrames = false

var LastDir = 1
var direction

var Combo = 1
var MaxCombo = 6
var ResetComboTimer = 0.0


var Cooldown1 :=0.0
var MeleeCooldown := 0.5
var CanMelee = true

var Cooldown2 := 0.0
var HeavyCooldown:= 0.7
var CanHeavy = true

const DashSpeed = 3000
var DashTimer:= 0.0

var UpTilt = false
var DownTilt = false

var MoveList = []


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		
		if Input.is_action_pressed(&"jump") and velocity.y <=-200:
			velocity += get_gravity() * delta * 2.05
		else:
			velocity += get_gravity() * delta *5

	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	direction = Input.get_axis("move_left", "move_right")
	
	if DashTimer >0:
		velocity = Vector2(DashSpeed*direction,0)
		DashTimer = max(0,DashTimer-delta*3)
	
	if direction and DashTimer <0.3:
		$Polygon2D.scale.x = direction
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	if LastDir != direction:
		LastDir = direction
	
	move_and_slide()
	
	if Cooldown1 <= MeleeCooldown:
		Cooldown1 += delta
	else:
		CanMelee = true
		Cooldown1 = 0.0
	
	if Cooldown2 <= HeavyCooldown:
		Cooldown2 += delta
	else:
		CanHeavy = true
		Cooldown2 = 0.0
	
	if Combo > 1:
		ResetComboTimer += delta
	if ResetComboTimer > 1.5:
		Combo = 1
		MoveList = []
		ResetComboTimer = 0.0
	$"../Camera2D/RichTextLabel".text = ",".join(MoveList)

func _input(event: InputEvent) -> void:

	if event.is_action_pressed("Attack"):
		if CanHeavy == true and CanMelee == true:
			LightAttack()

	if event.is_action_pressed("Mobility"):
		IFrames = true
		DashTimer = 1.0
		await get_tree().create_timer(0.3).timeout
		IFrames = false
		
	if event.is_action_pressed("up_tilt"):
		UpTilt = true
		
	if event.is_action_released("up_tilt"):
		UpTilt = false
	
	if event.is_action_pressed("down_tilt"):
		DownTilt = true
		
	if event.is_action_released("down_tilt"):
		DownTilt = false
	
func TakeDamage(damage):
	if IFrames:
		return
	Health -= damage
	#print(Health)
	if Health <= 0:
		get_tree().reload_current_scene()

func LightAttack():
	CanMelee = false
	Combo += 1
	ResetComboTimer = 0.0
	var newMelee = meleeAttack.instantiate()
	get_tree().current_scene.add_child(newMelee)
	newMelee.Owner = "player"
	newMelee.direction = LastDir#sign(get_global_mouse_position().x-position.x)
	newMelee.position = position + Vector2(10 * LastDir,0)
	if LastDir == 1:
		newMelee.rotation=deg_to_rad(0)
	elif  LastDir == -1:
		newMelee.rotation=deg_to_rad(180)
	else: 
		newMelee.rotation=deg_to_rad(0)
	#newMelee.rotation= deg_to_rad(180)#self.get_angle_to(get_global_mouse_position())
	#if UpTilt == true:
	#	newMelee.CanUpTilt = true
	#	print("work")
	#MoveList.append("L")
	#CheckForCombo()
	#if Combo == MaxCombo:
	#	Combo = 1
	#	MoveList.clear()
	#	newMelee.KnockbackPower = 2000

func HeavyAttacks():
	CanHeavy = false
	Combo += 1
	ResetComboTimer = 0.0
	var newHeavy = HeavyAttack.instantiate()
	get_tree().current_scene.add_child(newHeavy)
	newHeavy.Owner = "player"
	newHeavy.direction = sign(get_global_mouse_position().x-position.x)
	newHeavy.position = position
	newHeavy.rotation=self.get_angle_to(get_global_mouse_position())
	#MoveList.append("H")
	#CheckForCombo()
	#if Combo == MaxCombo:
	#	Combo = 1
	#	MoveList.clear()

func CheckForCombo():
	var StringOfMoves = ",".join(MoveList)
	match StringOfMoves:
		"L,H,L,H,L":
			print("Spin Move")
		"L,L,L,L,H":
			print("Heavyist hit")
		"H,H,H,H,L":
			print("Final cut")
		"L,L,L,H,H":
			print("Tons of pokes")
		"L,H,H":
			print("ground slam")
			Combo = MaxCombo
