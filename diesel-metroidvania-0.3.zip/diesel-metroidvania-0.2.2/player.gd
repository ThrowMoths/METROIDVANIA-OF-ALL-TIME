extends CharacterBody2D

@onready var meleeAttack:= preload("res://MeleeAttack.tscn")
@onready var HeavyAttack:= preload("res://heavy_attack.tscn")
@onready var bullet:=preload("res://Bullet.tscn")
const SPEED = 700.0
var speedMulti:=1.0
const JUMP_VELOCITY = -1000.0

var Health = 100
var IFrames = false

var LastDir = 1
var direction

var AtkRange = 300

var Combo = 1
var MaxCombo = 6
var ResetComboTimer = 0.0
var CanDblJump = true

var Cooldown1 :=0.0
var MeleeCooldown := 0.5
var CanMelee = true

var Cooldown2 := 0.0
var HeavyCooldown:= 0.7
var CanHeavy = true

const DashSpeed = 3000
var dashDuration:=0.2
var DashTimer:= 0.0
var dashCharge:=0.0
var dashCooldown:=0.0

var UpTilt = false
var DownTilt = false
var MoveList = []


func _physics_process(delta: float) -> void:
	$Firepoint.position.x=LastDir*80
	$DetAtk.target_position.x = AtkRange*LastDir
	if Input.is_action_pressed("Mobility"):
		dashCharge+=delta
		speedMulti=1.8
	else:
		speedMulti=1.0
	dashCooldown-=delta
	
	if not is_on_floor():
		if Input.is_action_pressed(&"jump") and velocity.y <=-200:
			velocity += get_gravity() * delta * 2.05
		else:
			velocity += get_gravity() * delta *5
	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	direction = Input.get_axis("move_left", "move_right")
	
	if DashTimer >0:
		velocity = Vector2(DashSpeed*LastDir,0)
		DashTimer = max(0,DashTimer-delta)
	
	if direction and DashTimer ==0:
		LastDir=direction
		$Polygon2D.scale.x = direction
		velocity.x = direction * SPEED*speedMulti
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
	
	
	move_and_slide()
	
	if Cooldown1 <= MeleeCooldown:
		Cooldown1 += delta
	else:
		CanMelee = true
		Cooldown1 = 0.0
	
	if Cooldown2 <= HeavyCooldown:
		Cooldown2 += delta
	else:
		CanHeavy = true
		Cooldown2 = 0.0
	
	
	if Combo > 1:
		ResetComboTimer += delta
	if ResetComboTimer > 1.5:
		Combo = 1
		#MoveList = []
		ResetComboTimer = 0.0

func _input(event: InputEvent) -> void:

	if event.is_action_pressed("Attack"):
		if CanMelee == true:
			if $DetAtk.is_colliding() and $DetAtk.get_collider().is_in_group("Enemy"):
				LightAttack()
			else:
				shoot()


	if event.is_action_released("Mobility"):
		if dashCharge<0.2 and dashCooldown<=0:
			dash()
		else:
			LightAttack()
		dashCharge=0.0
		
	
	if event.is_action_pressed("up_tilt"):
		UpTilt = true
		
	if event.is_action_released("up_tilt"):
		UpTilt = false
	
	if event.is_action_pressed("down_tilt"):
		DownTilt = true
		
	if event.is_action_released("down_tilt"):
		DownTilt = false
	
func TakeDamage(damage):
	if IFrames:
		return
	Health -= damage
	#print(Health)
	if Health <= 0:
		get_tree().reload_current_scene()

func LightAttack():
	CanMelee = false
	#Combo += 1
	#ResetComboTimer = 0.0
	var newMelee = meleeAttack.instantiate()
	get_tree().current_scene.add_child(newMelee)
	newMelee.Owner = "player"
	newMelee.direction = LastDir
	newMelee.position = position + Vector2(20 * $Polygon2D.scale.x,0)
	if $Polygon2D.scale.x == 1:
		newMelee.rotation=deg_to_rad(0)
	elif  $Polygon2D.scale.x == -1:
		newMelee.rotation=deg_to_rad(180)
	else: 
		newMelee.rotation=deg_to_rad(0)

func shoot():
	CanMelee = false
	var newbullet = bullet.instantiate()
	get_tree().current_scene.add_child(newbullet)
	newbullet.Owner = "player"
	newbullet.direction = LastDir
	newbullet.global_position = position

func dash():
		IFrames = true
		DashTimer = dashDuration
		await get_tree().create_timer(dashDuration+0.2).timeout
		IFrames = false
		#LightAttack()
		dashCooldown=1.0


func HeavyAttacks():
	CanHeavy = false
	Combo += 1
	ResetComboTimer = 0.0
	var newHeavy = HeavyAttack.instantiate()
	get_tree().current_scene.add_child(newHeavy)
	newHeavy.Owner = "player"
	newHeavy.direction = sign(get_global_mouse_position().x-position.x)
	newHeavy.position = $Firepoint.global_position
	newHeavy.rotation=self.get_angle_to(get_global_mouse_position())
